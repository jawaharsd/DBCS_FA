package application;

import java.awt.Desktop;

import java.io.*;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Iterator;
import java.util.ResourceBundle;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

import javafx.stage.Stage;

/**
 * 
 * 
 * @author Jawahar, 
 * Gradebook Tool
 * 
 *
 */



public class MainController extends Application implements Initializable {
	private Connection con;
	{
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final","root","jawahar1");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	@FXML
	private TextField reg_no;
	@FXML
	private TextField roll_no;
	@FXML
	private TextField name;
	@FXML
	private TextField Father_name;
	@FXML
	private TextField mother_name;
	@FXML
	private TextField course;
	
	@FXML
	private Button studentSubmitButton;
	@FXML
	private TextField RollNumber;
	@FXML
	private Button Student_Marks;
	@FXML
	private Button Subject_Marks;
	@FXML
	private Button browseBtnStudent;
	@FXML 
	private Button browseBtnInternal;
	@FXML 
	private Button browseBtnSubject;
	@FXML
	private Hyperlink hl;
	@FXML 
	private Button browseBtnGrade;
	@FXML
	private Button Gradebook;
	@FXML
	private Button Internal_Score;
	@FXML
	private Button Report_Generation;
	@FXML
	private TextField Browse_Address_Student;
	@FXML
	private TextField Browse_Address_Subject;
	@FXML
	private TextField Browse_Address_Internal;
	@FXML
	private TextField Browse_Address_Gradebook;
	@FXML
	private ComboBox<String> Semester;
	@FXML
	private ComboBox<String> Year;
	@FXML
	private ComboBox<String> Subjects;
	@FXML
	private Button subjectSubmitButton;
	@FXML 
	private Button gradeSubmitButton;
	@FXML
	private Button internalScoreSubmitButton;
	File f;

	@Override
	public void initialize (URL arg0, ResourceBundle arg1) {
		
		
		if (Semester ==null) Semester = new ComboBox<String>();
		if (Year == null) Year = new ComboBox<String>();
		if (Subjects ==null) Subjects = new ComboBox<String>();
		Semester.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8");
		Year.getItems().addAll("1", "2", "3", "4");
		Subjects.getItems().addAll("DBCS", "Big Data");
		if (browseBtnStudent == null) browseBtnStudent = new Button();
		if (browseBtnSubject == null) browseBtnSubject = new Button();
		if (browseBtnInternal == null) browseBtnInternal = new Button();
		if (browseBtnGrade == null) browseBtnGrade= new Button();
		browseBtnStudent.setOnAction(e->{
			try {
				browseAction(0);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		browseBtnSubject.setOnAction(e->{
			try {
				browseAction(1);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		browseBtnInternal.setOnAction(e->{
			try {
				browseAction(2);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		browseBtnGrade.setOnAction(e->{
			try {
				browseAction(3);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
	
		
	}
	
	public void Student_Marks() throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass()
				.getResource("/application/Student_Master.fxml"));
		Parent root1 = (Parent) fxmlLoader.load();
		Stage mainStage = new Stage();
		mainStage.setTitle("Student Master");
		mainStage.setScene(new Scene(root1));
		mainStage.show();
	}


	public void browseAction(int caller) throws IOException {
		//    	Browse_Address = new TextField();
		FileChooser fc = new FileChooser();
		fc.getExtensionFilters().add(new ExtensionFilter("Excel Files","*.xlsx"));
		fc.setTitle("Browse Excel File");
		f = fc.showOpenDialog(null);
		if (f != null) {
		switch (caller) {
		case 0:
			Browse_Address_Student.setText(f.getAbsolutePath());
			break;
		case 1:
			Browse_Address_Subject.setText(f.getAbsolutePath());
			break;

		case 2:
			Browse_Address_Internal.setText(f.getAbsolutePath());
			break;

		case 3:
			Browse_Address_Gradebook.setText(f.getAbsolutePath());
			break;

		}
		}
	}

public void saveInStudentMaster() throws SQLException, IOException {
	   int Reg_no = Integer.parseInt(reg_no.getText());
int Roll_no = Integer.parseInt(roll_no.getText());
String name_s = name.getText();
String father_name = Father_name.getText();
String m_name = mother_name.getText();
String cour = course.getText();
		int semester = Integer.parseInt(Semester.getSelectionModel().getSelectedItem());
		int year = Integer.parseInt(Year.getSelectionModel().getSelectedItem());
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final","root","jawahar1");
		String sql = "insert into regestration(Reg_no,Roll_no ,Name,Father_Name,Mother_Name,Course,Semester,year)" + "values"+"(?,?,?,?,?,?,?,?)";
		PreparedStatement pstm = con.prepareStatement(sql);
		pstm.setInt(1, Reg_no);
		pstm.setInt(2, Roll_no);
		pstm.setString(3, name_s);
		pstm.setString(4, father_name);
		pstm.setString(5, m_name);
		pstm.setString(6, cour);
		pstm.setInt(7, semester);
		pstm.setInt(8, year);
		pstm.execute();
		FileInputStream input = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(input);
		XSSFSheet sheet = wb.getSheetAt(0);
		XSSFRow row;
	
			
			
			System.out.println("Connectiong to Database...");
			System.out.println("Connected to Database");
			System.out.println("Stating import...");
			System.out.println("Database Importing row ");
		
		pstm.close();
		con.close();
		input.close();
		System.out.println("Success import excel to mysql table");
	}
	
	public int getLastRowWithData(XSSFSheet currentSheet) {
		int rowCount = 0;
		Iterator<org.apache.poi.ss.usermodel.Row> iter = currentSheet.rowIterator();

		while (iter.hasNext()) {
			org.apache.poi.ss.usermodel.Row r = iter.next();
			if (!this.isRowBlank(r)) {
				rowCount = r.getRowNum();
			}
		}

		return rowCount;
	}
	
	
	public float retrieveSubjectwise(int rollno,String subject) throws SQLException {
		String retQuery = "select * from internal_score_master where roll_no = "+rollno+"  and subjet_name = \""+subject+"\"";
		ResultSet theStudentResult = con.createStatement().executeQuery(retQuery);
		float w1sh1 = 0;
		float w2sh1 = 0;
		float w3sh1_2 = 0;
		float w1sh2 = 0;
		float w2sh2 = 0;
		float w4sh2 = 0;
		float w5sh2 = 0;
		float w6sh2 = 0;
		float w4sh1 = 0;
		float w5sh1 = 0;
		float w6sh1 = 0;
		float w1enb = 0;
		float w2enb = 0;
		float 	w3enb = 0;
		float 	w4enb =0;
		float 	w5enb = 0;
		float w6enb = 0;
		while (theStudentResult.next()) {
			w1sh1 = theStudentResult.getFloat("w1sh1");
			w2sh1 = theStudentResult.getFloat("w2sh1");
			w3sh1_2 = theStudentResult.getFloat("w3sh1_2");
			w1sh2 = theStudentResult.getFloat("w1sh2");
			w2sh2 = theStudentResult.getFloat("w2sh2");
			w4sh2 = theStudentResult.getFloat("w4sh2");
			w5sh2 = theStudentResult.getFloat("w5sh2");
			w6sh2 = theStudentResult.getFloat("w6sh2");
			w4sh1 = theStudentResult.getFloat("w4sh1");
			w5sh1 = theStudentResult.getFloat("w5sh1");
			w6sh1 = theStudentResult.getFloat("w6sh1");
			w1enb = theStudentResult.getFloat("w1enb");
			w2enb = theStudentResult.getFloat("w2enb");
			w3enb = theStudentResult.getFloat("w3enb");
			w4enb = theStudentResult.getFloat("w4enb");
			w5enb = theStudentResult.getFloat("w5enb");
			w6enb = theStudentResult.getFloat("w6enb");
		}
		float sh  = w1sh1+w1sh2+w2sh1+w2sh2+w3sh1_2+w4sh1+w4sh2+w5sh1+w5sh2+w6sh1+w6sh2;
		float enb = w1enb +w2enb+w3enb+w4enb+w5enb+w6enb;
		float x,y,x2,y2 = 0;
		float theScore = 0;

		switch(subject) {
		case "Big Data":
			x = (float)(sh*1.08)/120;
			y = (float)(enb*1.07/600);
			theScore = (float) ((x+y)*100/(1.08+1.07));
			break;
		case "DBCS":
			x2 = (float)(sh*1.36)/120;
			y2= (float)(enb*0.83/600);
			theScore = (float) ((x2+y2)*100/(1.36+0.83));
			break;
		}
		return theScore;


	}
	public void generateOverallReport() throws SQLException, DocumentException, IOException {
		
		ResultSet setOfRollNumbers = con.createStatement().executeQuery("select * from regestration group by roll_no");
		Document theOverallReport = new Document();
		PdfWriter.getInstance(theOverallReport, new FileOutputStream("regestration.pdf"));
		theOverallReport.open();
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
		Date date = new Date(System.currentTimeMillis());
		Paragraph p = new Paragraph("Regestration report (Off all students)\n\n\n");
		theOverallReport.add(p);
		Paragraph end = new Paragraph("\n\n Report Generated on "+formatter.format(date));
		PdfPTable table = new PdfPTable(4);
		table.addCell("Roll Number"); table.addCell("Name"); table.addCell("Total score of Big Data"); table.addCell("Total score of DBCS");
		while(setOfRollNumbers.next()) {
	
			int theRollNumber = setOfRollNumbers.getInt("roll_no");
			ResultSet rn = con.createStatement().executeQuery("select * from regestration group by roll_no");
			String theStudentName ="";
			while(rn.next()) theStudentName = rn.getString("name");
			table.addCell(String.valueOf(theRollNumber)); table.addCell(theStudentName);
		}
		theOverallReport.add(table);
		theOverallReport.add(end);
		theOverallReport.close();
		Desktop.getDesktop().open(new File("regestration.pdf"));

	}


	public boolean isRowBlank(org.apache.poi.ss.usermodel.Row r) {
		boolean ret = true;

		/*
		 * If a row is null, it must be blank.
		 */
		if (r != null) {
			Iterator<org.apache.poi.ss.usermodel.Cell> cellIter = r.cellIterator();
			/*
			 * Iterate through all cells in a row.
			 */
			while (cellIter.hasNext()) {
				/*
				 * If one of the cells in given row contains data, the row is
				 * considered not blank.
				 */
				if (!isCellBlank(cellIter.next())) {
					ret = false;
					break;
				}
			}
		}

		return ret;
	}


	public boolean isCellBlank(org.apache.poi.ss.usermodel.Cell cell) {
		return (cell == null || cell.getCellType() == CellType.BLANK);
	}

	public boolean isCellEmpty(org.apache.poi.ss.usermodel.Cell c) {
		return (c == null || c.getCellType() == CellType.BLANK || (c
				.getCellType() == CellType.STRING && c
				.getStringCellValue().isEmpty()));
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	
		
	}




}


